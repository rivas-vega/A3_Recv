# Reconstructed experiment record

This record supports the one-page English report. It is not an additional page to submit with the report.

## Evidence and limits

- **Public scores:** the ten-row Kaggle submission history supplied by Pedro in this chat. These were not independently queried from the private competition, and are not private-leaderboard results.
- **Methods:** repository [rivas-vega/A3_Recv](https://github.com/rivas-vega/A3_Recv), inspected at commit `0c7aa9f4f047df746527a9a2861a4c5ea3de17d0` (17 November 2026), including its earlier commits.
- **Executed MobileCLIP run:** outputs preserved in [mobileclip_s0_cinic.ipynb](https://github.com/rivas-vega/A3_Recv/blob/7c72f4eec6945f76fdcb67b9090f20b7962d5fd8/mobileclip_s0_cinic.ipynb). These provide actual data counts, epochs, validation scores, GPU and elapsed training time. The README's older statement that training was pending is superseded by these outputs and the supplied Kaggle result.
- **ResNet validation:** 96.04% and 96.56%, 30 completed epochs and epoch 29 selected, are documented as participant-reported results in the README; original training logs were not available in the inspected notebook.
- **Shared ChatGPT conversation:** the supplied share URL could not be retrieved (browser fetch failed; direct request returned HTTP 503). This reconstruction therefore does not claim to recover its verbatim content.
- **User clarification:** RGB histograms and optimal transport were exploratory and did not enter any submitted model. This was explicitly confirmed in the present chat.

## All ten Kaggle submissions

The order below follows the experimental stages. It does not infer an ordering between submissions within the same day.

| Submission | Method | Public score | Accuracy |
|---|---|---:|---:|
| `submission_baseline.csv` | ImageNet ResNet-18, basic augmentation | 0.61093 | 61.093% |
| `submission_augmix.csv` | ResNet-18, AugMix and JSD consistency | 0.75796 | 75.796% |
| `submission_dinov3_linear_256.csv` | DINOv3 ConvNeXt-Base, frozen encoder and linear head | 0.82269 | 82.269% |
| `submission_dinov3_partial_ft_256.csv` | DINOv3 ConvNeXt-Base, partial fine-tuning and mild AugMix/JSD | 0.86217 | 86.217% |
| `submission_siglip_probe.csv` | SigLIP 2 Giant, supervised linear head | 0.92019 | 92.019% |
| `submission_dino_7b_probe.csv` | DINOv3 ViT-7B, supervised linear head | 0.92978 | 92.978% |
| `submission_siglip_zero_shot.csv` | SigLIP 2 Giant, public text templates, full image and flip | 0.94015 | 94.015% |
| `submission_vit_ensemble.csv` | SigLIP zero-shot / SigLIP probe / DINO probe, 50/25/25 | 0.94844 | 94.844% |
| `submission_pe_zero_shot.csv` | PE-Core-G14-448 zero-shot, full image and flip | 0.96776 | 96.776% |
| `submission_mobileclip2_s0_cinic.csv` | Supervised MobileCLIP2-S0 fine-tuning on CINIC-10 | 0.84364 | 84.364% |

## 1. Initial image exploration (11 November)

Early commits compare quantization, contrast and bilinear upsampling. A later [historical notebook](https://github.com/rivas-vega/A3_Recv/blob/6f30b0d304/main_notebook.ipynb) computes full-test RGB histograms and independent one-dimensional optimal transport plans for the red, green and blue intensity distributions. It visualizes deterministic barycentric lookup tables on random images. This is marginal RGB transport, not joint three-dimensional color transport.

These operations use aggregate unlabeled test statistics and are transductive exploration. They were discarded before the scored pipelines, as confirmed by the user and consistent with the later code. The report discloses this inspection without mischaracterizing the scored predictions as adapted using test statistics. It does not claim that no test images or statistics were ever inspected.

## 2. ResNet-18 baseline and augmentation (11 November)

Source: [resnet18_augmix.ipynb](https://github.com/rivas-vega/A3_Recv/blob/0c7aa9f4f047df746527a9a2861a4c5ea3de17d0/resnet18_augmix.ipynb).

Both models start from identical `ResNet18_Weights.IMAGENET1K_V1` weights and fine-tune all layers. Source images are 32 x 32. Crop with padding 4 and horizontal flip precede a single bilinear, antialiased resize to 128 x 128 and ImageNet normalization. The baseline uses cross-entropy. AugMix adds two augmented views and a Jensen-Shannon consistency term of weight 12; severity 3, mixture width 3, random depth, alpha 1 and `all_ops=True`.

AdamW uses backbone/head learning rates 3e-4/1e-3, weight decay 1e-4, batch size 128, seed 42, two warmup epochs and a cosine schedule. Both completed 30 epochs; epoch 29 was selected. Validation/test inference uses only the full image, without AugMix or test-time adaptation.

The validation gain is 0.52 percentage points, while the public-test gain is **14.703 pp**. This is the clearest comparison for the benefit of the augmentation protocol in this project, although there are no repeated-seed error bars.

## 3. DINOv3 ConvNeXt-Base (11 November)

Source: [main_notebook.ipynb](https://github.com/rivas-vega/A3_Recv/blob/0c7aa9f4f047df746527a9a2861a4c5ea3de17d0/main_notebook.ipynb).

The exact checkpoint is `facebook/dinov3-convnext-base-pretrain-lvd1689m`. This is a **CNN**, distinct from the later ViT-7B. Its published weights were distilled from a large DINOv3 teacher; that teacher was not executed as part of this adaptation. Inputs are enlarged directly to 256 x 256 and normalized with ImageNet statistics.

The linear probe trains a ten-class head on frozen original/flip features: AdamW 1e-3, up to 100 epochs, patience 10 after epoch 10. Partial fine-tuning starts from that probe and trains the last ConvNeXt stage, final LayerNorm and head. It uses encoder/head rates 1e-5/1e-4, one warmup epoch, a cosine schedule, padding-2 crops, flips, AugMix severity 2 and JSD weight 6; up to 10 epochs with early stopping. The reported Kaggle gain is **3.948 pp**. It cannot be attributed solely to unfreezing because augmentation also changes. Actual completed DINO epoch counts were not recovered.

## 4. SigLIP 2 Giant, DINOv3 ViT-7B and ensemble (11-12 November)

Sources: [semantic_vit.py](https://github.com/rivas-vega/A3_Recv/blob/fc538b90a48c2c1ce7cd8f3f96045653478744e9/semantic_vit.py) and [vit_semantic.ipynb](https://github.com/rivas-vega/A3_Recv/blob/0c7aa9f4f047df746527a9a2861a4c5ea3de17d0/vit_semantic.ipynb).

- SigLIP checkpoint: `google/siglip2-giant-opt-patch16-384`, published WebLI pretraining; 384 x 384 inputs, official 0.5/0.5 normalization. The frozen visual encoder is used both with a supervised linear head and with text prototypes.
- DINO checkpoint: `facebook/dinov3-vit7b16-pretrain-lvd1689m`, published LVD-1689M pretraining; 256 x 256 inputs, ImageNet normalization, concatenated CLS and mean patch descriptors excluding register tokens. Only the linear head is trained.
- Heads train on original and a deterministic mild AugMix feature view, with AdamW, initial LR 1e-3, cosine decay, up to 80 epochs and patience 10 after epoch 10. Head selection averages clean and augmented validation accuracy.
- The original validation set is stratified 20/20/60% for selection, temperature calibration and reporting. Its reuse after earlier experiments means the final partition is not a new independent benchmark.
- Text prototypes use all 80 existing public OpenCLIP ImageNet templates, unchanged apart from inserting the official CIFAR-10 class names. No language model generates prompts. Original and horizontal-flip features are averaged for SigLIP inference.
- The ensemble averages calibrated probabilities with weights **0.50 SigLIP zero-shot + 0.25 SigLIP probe + 0.25 DINO probe**. These weights are fixed in the code, rather than optimized against the public leaderboard.

SigLIP zero-shot beats its supervised head by **1.996 pp**. The ensemble adds **0.829 pp** over SigLIP zero-shot. These observations are consistent with useful semantic transfer and complementary predictions; they do not isolate a causal explanation.

## 5. PE-Core-G14-448: best evaluated result (12 November)

Sources: [pe_semantic.py](https://github.com/rivas-vega/A3_Recv/blob/c30fc5422f23728a42cdc18741dac7ef52a7154c/pe_semantic.py), [didactic reproduction notebook](https://github.com/rivas-vega/A3_Recv/blob/0c7aa9f4f047df746527a9a2861a4c5ea3de17d0/pe_zero_shot_didactic.ipynb) and [official model card](https://huggingface.co/facebook/PE-Core-G14-448).

The frozen image-text model has an approximately 1.88B-parameter visual tower and 0.47B-parameter text tower; shared embeddings have 1,280 dimensions. The visual tower is a 50-block ViT with 14 x 14 patches, operating on a 448 x 448 bilinear enlargement. Upsampling changes the model's input representation but creates no recovered detail. The official preprocessing normalizes each channel with mean and standard deviation 0.5.

For each class, normalize the embeddings of its 80 templated names, average them, then normalize again. Average image-text cosine scores from the full image and its horizontal reflection and take the largest score. No classifier head or encoder weights are fitted to the assignment labels. A positive temperature is fitted on labeled validation for probabilities; it cannot change the class argmax.

The submitted score **0.96776** belongs to this two-view zero-shot model, not to the local-crop or PE+SigLIP candidates also present in the experimental code. The local-crop candidate ranks uncertainty across a dataset; it is outside this reported submission and outside the packaged PE-only reproduction route.

PE improves on the ResNet baseline by **35.683 pp**, and on the earlier ensemble by **1.932 pp**, corresponding to approximately **37.47% relative error reduction** against that ensemble. The best public score was observed during development; it is not an unbiased private-test estimate. There is no submitted PE-without-flip ablation or isolated input-resolution ablation.

## 6. MobileCLIP2-S0 and CINIC-10 (16 November)

This later experiment investigates a much smaller classifier and external labeled data. It does **not** improve the best public score.

CINIC-10 combines CIFAR-10 with downsampled ImageNet images. Only its train and validation splits are downloaded from a revision-pinned Flower mirror, whose image names, pixels and labels were checked against the original archive. The code does not concatenate competition training images into CINIC a second time, and does not use CINIC test or CIFAR-10-Warehouse.

Recorded counts: 90,000 initial training images become **87,804** after exact RGB and horizontal-mirror deduplication and split separation. The 90,000 validation images leave 89,194 disjoint unique candidates; a stratified **10,000**, 1,000 per class, are used for checkpoint selection. Competition validation contains 10,000 images and is evaluated after checkpoint selection. Exact deduplication is not a guarantee against all near duplicates.

The checkpoint is `timm/MobileCLIP2-S0-OpenCLIP`, revision `095906d28bf54d7584dc411e8ffe448f34289e05`. Its visual tower and new head total **11,412,106 parameters**. Inputs are resized to 256 x 256 with official preprocessing; weak crop/flip/color jitter augment training. Three head-only epochs use LR 1e-3, then full fine-tuning uses encoder/head LR 1e-5/1e-4 with frozen BatchNorm statistics, AdamW weight decay 0.01 and label smoothing 0.05.

The saved run completed **25 epochs**, selected **epoch 25**, used an **NVIDIA L4**, and recorded **3.613 training hours** (not total end-to-end preparation time). It reached **94.78% CINIC selection accuracy**, **97.99% competition validation accuracy**, and **84.364% public Kaggle accuracy**. Maximum allocated GPU memory recorded by the run was 10.71 GB. Its upstream pretraining used distillation; no additional teacher, prompts or distillation were used in this assignment experiment. Without a matched MobileCLIP experiment trained only on competition data, the isolated effect of CINIC cannot be estimated.

## Reporting and hand-in decisions

The revised PDF tells the experimental progression from CNN augmentation and interpolation/color exploration, through distilled DINOv3 CNN weights, large ViTs, zero-shot classifiers and ensembles, to PE and the later 11.4M-parameter MobileCLIP comparison. It has one page of main content and a separate references page in the requested CVPR2024-v2 style. No unfinished experiment is discussed in the report.

The code ZIP contains five Colab notebooks covering all ten scored submissions, plus the initial exploration notebook, the three required helper modules and retained licenses. Notebook outputs and widget metadata are stripped. No pretrained weights, datasets, credentials or predictions are bundled. Full training/inference was not rerun; Python cell syntax, module hashes and archive integrity were checked. The teacher permits notebooks in the code ZIP and says that final-model code is sufficient; all scored stages are provided here to document the requested progression.
